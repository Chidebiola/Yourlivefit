import { NextResponse } from "next/server";
import PipelineSingleton from "../api/baseImage/pipeline.js";
import Jimp from "jimp";
import path from "path";

//TAKE A URL AND Change the clothes, arms, legs, and shoes to a transparent mask

export async function GET(request) {
  const url =
    "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=2124&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D";
  // Get the segmentation pipeline. When called for the first time,
  // this will load the pipeline and cache it for future use.
  const segmenter = await PipelineSingleton.getInstance();

  console.log("Segmenter function is about to be called with URL:", url);

  // Actually perform the segmentation
  const output = await segmenter(url);
  console.log("Segmentation result:", output);

  // Load the original image
  const image = await Jimp.read(url);

  // Get the masks for the clothes, arms, legs, and shoes
  const labels = ['Upper-clothes', 'Pants', 'Left-shoe', 'Right-shoe', 'Left-arm', 'Right-arm', 'Left-leg', 'Right-leg'];
  const masks = output.filter(segment => labels.includes(segment.label)).map(segment => segment.mask);

  // Set the pixels in the masks to transparent in the original image
  masks.forEach(mask => {
    for (let y = 0; y < mask.height; y++) {
      for (let x = 0; x < mask.width; x++) {
        if (mask.data[y * mask.width + x]) {
          image.setPixelColor(Jimp.rgbaToInt(0, 0, 0, 0), x, y);
        }
      }
    }
  });

  // Save the result
  const resultPath = path.join(process.cwd(), "/public/result.png");
  await image.writeAsync(resultPath);

  return NextResponse.json({
    message: "Image processed successfully",
    resultPath,
  });
}



// // route.js
// import { NextResponse } from 'next/server'
// import PipelineSingleton from './pipeline.js';
// import Jimp from "jimp";
// import path from "path";

// export async function GET(request) {
//     const url = "https://freerangestock.com/sample/139043/young-man-standing-and-leaning-on-car.jpg"
//     // Get the segmentation pipeline. When called for the first time,
//     // this will load the pipeline and cache it for future use.
//     const segmenter = await PipelineSingleton.getInstance();

//     console.log('Segmenter function is about to be called with URL:', url);

//     // Actually perform the segmentation
//     const output = await segmenter(url);
//     if (typeof output.width !== 'number' || typeof output.height !== 'number') {
//       throw new Error('Invalid output from segmenter function: width and height must be numbers');
//     }

//     console.log('Segmentation result:', output);

//     // Load the original image and the mask
//     const image = await Jimp.read(url).catch(error => {
//         throw new Error(`Invalid image URL: ${url}`);
//       });

//       const mask = new Jimp(output.width, output.height, (error, image) => {
//         if (error) {
//           throw new Error('Invalid output data from segmenter function: cannot create Jimp image');
//         }
//       });
//     // Create the mask image
//     for (let y = 0; y < output.height; y++) {
//       for (let x = 0; x < output.width; x++) {
//         const value = output.data[y * output.width + x] ? 255 : 0;
//         mask.setPixelColor(Jimp.rgbaToInt(value, value, value, 255), x, y);
//       }
//     }

//     // Apply the mask to the original image
//     image.mask(mask, 0, 0);

//     // Save the result
//     const resultPath = path.join(process.cwd(), "/public/result.jpg");
//     await image.writeAsync(resultPath);

//     return NextResponse.json({ message: "Image processed successfully", resultPath });
// }
