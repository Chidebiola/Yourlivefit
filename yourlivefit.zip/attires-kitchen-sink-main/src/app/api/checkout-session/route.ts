import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { getURL } from "@/lib/getURL";
import { currentUser } from "@clerk/nextjs";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
const currentURL = getURL();
const YOUR_DOMAIN = currentURL;
let stripeId;

// console.log(currentURL)

export async function POST(req: NextRequest) {
  const body = await req.json();
  // console.log(body);
  console.log(currentURL, "CURERENT URL");
  // console.log(user, 'USER ON SERVER')

  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
    apiVersion: "2023-10-16",
  });

  //replace with Clerk session check
  // const session = await getServerSession(authOptions)

  // const user = await currentUser();
  // if (!user) {
  //   return NextResponse.json({
  //     error: {
  //       code: "no-access",
  //       message: "you are not signed in",
  //     },
  //     status: 401,
  //   });
  // }

  // const prismaUser = await prisma.test.findUnique({
  //   where: {
  //     userId: user.id
  //   }
  // });

  // if (!prismaUser) {
  //   return NextResponse.json({
  //     error: {
  //       code: "no-access",
  //       message: "something went wrong with db"
  //     },
  //     status: 401,
  //   })
  // }

  //check if user has stripe ID
    //create a new customer

  // if (prismaUser.stripeId === null) {
  //   const customer = await stripe.customers.create({
  //     email: user.emailAddresses[0].emailAddress, //
  //     name: user.firstName + " " + user.lastName,
  //   });
  //   stripeId = customer.id;
  // } else {
  //   stripeId = prismaUser.stripeId
  // }

  const checkoutSession = await stripe.checkout.sessions.create({
    mode: "subscription",
    // customer: stripeId,
    line_items: [
      {
        price: body.priceId,
        quantity: 1,
      },
    ],
    success_url: `${YOUR_DOMAIN}/?success=true&session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${YOUR_DOMAIN}?canceled=true`,
    subscription_data: {
      metadata: {
        payingUserId: "meow",
      },
      trial_period_days: 10,
    },
  });

  //if new customer save the ID (and load next time even if they don't pay.)
  // const saveStripeId = await prisma.test.create({
  //   data: {
  //     stripeId: customer.id,
  //   },
  // });

  return NextResponse.json(
    {
      session: checkoutSession,
    },
    {
      status: 200,
    }
  );
}
