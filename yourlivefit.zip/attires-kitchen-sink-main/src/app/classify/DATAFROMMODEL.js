// route.js
import { NextResponse } from 'next/server'
import PipelineSingleton from '../api/baseImage/pipeline.js';

export async function GET(request) {
    const url = "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=2124&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    // Get the segmentation pipeline. When called for the first time,
    // this will load the pipeline and cache it for future use.
    const segmenter = await PipelineSingleton.getInstance();

    console.log('Segmenter function is about to be called with URL:', url);

    // Actually perform the segmentation
    const result = await segmenter(url);
        console.log('Segmentation result:', result);


    return NextResponse.json(result);
}

