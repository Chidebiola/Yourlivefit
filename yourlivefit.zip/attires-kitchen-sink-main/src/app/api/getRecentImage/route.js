import { PrismaClient } from "@prisma/client";
import { NextResponse } from "next/server";

const prisma = new PrismaClient();

export const maxDuration = 100;
export const fetchCache = 'force-no-store';
export const revalidate = 0;

export async function GET(req, res) {
  try {
    const newestEntry = await prisma.test.findFirst({
      orderBy: {
        id: "desc",
      },
    });

    if (!newestEntry) {
      return res.status(404).json({ error: "No entries found" });
    }

    return NextResponse.json({
        url: newestEntry.url,
        urlWhiteBg: newestEntry.urlWhiteBg,
        urlMask: newestEntry.urlMask,
        success: true,
    });
  } catch (error) {
    return NextResponse.json({
      error: error.message,
    });
  }
}
