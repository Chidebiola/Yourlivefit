import OpenAI from "openai";
import fetch from "node-fetch";
import FormData from "form-data";
import PipelineSingleton from "./pipeline.js";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import Jimp from "jimp";


export const maxDuration = 100;

const s3Client = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

export async function POST(request) {
  console.log('HEREEEEEE IN THE DALLEEEDITWHITEBG')
  // console.log("request", request);
  const { url } = await request.json();
  // console.log("url", url)
  const fileName = 'meow'

  const segmenter = await PipelineSingleton.getInstance();
  const output = await segmenter(url);
  const image = await Jimp.read(url);
  const backgroundMask = output.find(
    (segment) => segment.label === "Background"
  ).mask;
  for (let y = 0; y < backgroundMask.height; y++) {
    for (let x = 0; x < backgroundMask.width; x++) {
      if (backgroundMask.data[y * backgroundMask.width + x]) {
        image.setPixelColor(Jimp.rgbaToInt(255, 255, 255, 255), x, y);
      }
    }
  }
  const processedImageBuffer = await image.getBufferAsync(Jimp.MIME_JPEG);
  const key = `${fileName}-whiteBackground-${Date.now()}`;
  const params = {
    Bucket: process.env.AWS_BUCKET_NAME,
    Key: key,
    Body: processedImageBuffer,
    ContentType: "image/jpeg",
  };
  const command = new PutObjectCommand(params);
  await s3Client.send(command);
  const s3URLWhiteBG = `https://${process.env.AWS_BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`;
  // return s3URLWhiteBG;

  return new Response(JSON.stringify({ image: s3URLWhiteBG }), { status: 200 });
}
