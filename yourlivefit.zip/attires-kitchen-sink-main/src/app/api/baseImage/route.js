import { NextResponse } from "next/server";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { PrismaClient } from "@prisma/client";
import PipelineSingleton from "./pipeline.js";
import Jimp from "jimp";

export const maxDuration = 100;

const prisma = new PrismaClient();
const s3Client = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

async function uploadFileToS3(file, fileName) {
  // Convert image to PNG
  let image = await Jimp.read(file);

  if (image.getMIME() !== Jimp.MIME_PNG) {
    fileName = '/tmp/' + fileName.replace(/\.[^/.]+$/, "") + ".png";
    image = await image.writeAsync(fileName);
  }

  // Resize image if it's larger than 4 MB
  const maxSize = 4 * 1024 * 1024; // 4 MB in bytes
  if (image.bitmap.data.length > maxSize) {
    const scaleFactor = Math.sqrt(maxSize / image.bitmap.data.length);
    const width = Math.floor(image.bitmap.width * scaleFactor);
    const height = Math.floor(image.bitmap.height * scaleFactor);
    image = image.resize(width, height);
  }

  // Resize image to fit within 1024x1024
  const scaleFactor = 1024 / Math.max(image.bitmap.width, image.bitmap.height);
  let width = Math.floor(image.bitmap.width * scaleFactor);
  let height = Math.floor(image.bitmap.height * scaleFactor);
  image = image.resize(width, height);
  // Create a new 1024x1024 white image
  let transparentImage = new Jimp(1024, 1024, Jimp.rgbaToInt(0, 0, 0, 0));
  // Calculate the position to center the image
  let x = (1024 - width) / 2;
  let y = (1024 - height) / 2;
  // Composite the original image onto the white image
  transparentImage = transparentImage.composite(image, x, y);
  // Now use transparentImage instead of image
  image = transparentImage;

  const processedImageBuffer = await image.getBufferAsync(Jimp.MIME_PNG);
  const key = `${fileName}-${Date.now()}`;
  const params = {
    Bucket: process.env.AWS_BUCKET_NAME,
    Key: key,
    Body: processedImageBuffer,
    ContentType: "image/png",
  };
  const command = new PutObjectCommand(params);
  await s3Client.send(command);
  const s3URL = `https://${process.env.AWS_BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`;
  return s3URL;
}

async function whiteBackgroundImage(file, fileName) {
  const url = await uploadFileToS3(file, fileName);
  const segmenter = await PipelineSingleton.getInstance();
  const output = await segmenter(url);
  let image = await Jimp.read(url);
  if (image.getMIME() !== Jimp.MIME_PNG) {
    fileName = fileName.replace(/\.[^/.]+$/, "") + ".png";
    image = await image.getBufferAsync(Jimp.MIME_PNG);
    image = await Jimp.read(image);
  }
  const backgroundMask = output.find(
    (segment) => segment.label === "Background"
  ).mask;
  for (let y = 0; y < backgroundMask.height; y++) {
    for (let x = 0; x < backgroundMask.width; x++) {
      if (backgroundMask.data[y * backgroundMask.width + x]) {
        image.setPixelColor(Jimp.rgbaToInt(0, 0, 0, 0), x, y);
      }
    }
  }
  // Resize image if it's larger than 4 MB
  const maxSize = 4 * 1024 * 1024;
  if (image.bitmap.data.length > maxSize) {
    const scaleFactor = Math.sqrt(maxSize / image.bitmap.data.length);
    const width = Math.floor(image.bitmap.width * scaleFactor);
    const height = Math.floor(image.bitmap.height * scaleFactor);
    image = image.resize(width, height);
  }
  // Resize image to fit within 1024x1024
  const scaleFactor = 1024 / Math.max(image.bitmap.width, image.bitmap.height);
  let width = Math.floor(image.bitmap.width * scaleFactor);
  let height = Math.floor(image.bitmap.height * scaleFactor);
  image = image.resize(width, height);
  // Create a new 1024x1024 white image
  let transparentImage = new Jimp(1024, 1024, Jimp.rgbaToInt(0, 0, 0, 0));
  // Calculate the position to center the image
  let x = (1024 - width) / 2;
  let y = (1024 - height) / 2;
  // Composite the original image onto the white image
  transparentImage = transparentImage.composite(image, x, y);
  // Now use transparentImage instead of image
  image = transparentImage;

  const processedImageBuffer = await image.getBufferAsync(Jimp.MIME_PNG);
  const key = `${fileName}-whiteBackground-${Date.now()}`;
  const params = {
    Bucket: process.env.AWS_BUCKET_NAME,
    Key: key,
    Body: processedImageBuffer,
    ContentType: "image/png",
  };
  const command = new PutObjectCommand(params);
  await s3Client.send(command);
  const s3URLWhiteBG = `https://${process.env.AWS_BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`;
  return s3URLWhiteBG;
}

async function maskImage(file, fileName) {
  const url = await uploadFileToS3(file, fileName);
  const segmenter = await PipelineSingleton.getInstance();
  const output = await segmenter(url);

  let image = await Jimp.read(url);
  // Convert image to PNG
  if (image.getMIME() !== Jimp.MIME_PNG) {
    fileName = fileName.replace(/\.[^/.]+$/, "") + ".png";
    image = await image.getBufferAsync(Jimp.MIME_PNG);
    image = await Jimp.read(image);
  }

  // Create a new 1024x1024 white image
  let whiteImage = new Jimp(1024, 1024, Jimp.rgbaToInt(255, 255, 255, 255));

  // Resize image to fit within 1024x1024
  const scaleFactor = 1024 / Math.max(image.bitmap.width, image.bitmap.height);
  let width = Math.floor(image.bitmap.width * scaleFactor);
  let height = Math.floor(image.bitmap.height * scaleFactor);
  image = image.resize(width, height);
  
  // Calculate the position to center the image
  let x = (1024 - width) / 2;
  let y = (1024 - height) / 2;

  // Composite the original image onto the white image
  whiteImage = whiteImage.composite(image, x, y);

  const labels = [
    "Upper-clothes",
    "Pants",
    "Left-shoe",
    "Right-shoe",
    "Left-arm",
    "Right-arm",
    "Left-leg",
    "Right-leg",
  ];
  const masks = output
    .filter((segment) => labels.includes(segment.label))
    .map((segment) => segment.mask);

  // Apply the mask
  for (let mask of masks) {
    for (let y = 0; y < mask.height; y++) {
      for (let x = 0; x < mask.width; x++) {
        if (mask.data[y * mask.width + x]) {
          whiteImage.setPixelColor(Jimp.rgbaToInt(0, 0, 0, 0), x, y);
        }

      }
    }
  }

  // if ( mask.data[y * mask.width + x] !== 255 && mask.data[y * mask.width + x] !== 0) {
  //   console.log('mask.data[y * mask.width + x]', mask.data[y * mask.width + x])
  //   }
  // console.log('complete')


  const processedImageBuffer = await whiteImage.getBufferAsync(Jimp.MIME_PNG);
  const maskKey = `${fileName}-mask-${Date.now()}`;
  const maskParams = {
    Bucket: process.env.AWS_BUCKET_NAME,
    Key: maskKey,
    Body: processedImageBuffer,
    ContentType: "image/png",
  };
  const maskCommand = new PutObjectCommand(maskParams);
  await s3Client.send(maskCommand);
  const s3URLMaskImg = `https://${process.env.AWS_BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${maskKey}`;
  return s3URLMaskImg;
}
// async function maskImage(file, fileName) {
//   const url = await uploadFileToS3(file, fileName);
//   const segmenter = await PipelineSingleton.getInstance();
//   const output = await segmenter(url);

//   let image = await Jimp.read(url);
//   // Convert image to PNG
//   if (image.getMIME() !== Jimp.MIME_PNG) {
//     fileName = fileName.replace(/\.[^/.]+$/, "") + ".png";
//     image = await image.getBufferAsync(Jimp.MIME_PNG);
//     image = await Jimp.read(image);
//   }

//   const labels = [
//     "Upper-clothes",
//     "Pants",
//     "Left-shoe",
//     "Right-shoe",
//     "Left-arm",
//     "Right-arm",
//     "Left-leg",
//     "Right-leg",
//   ];
//   const masks = output
//     .filter((segment) => labels.includes(segment.label))
//     .map((segment) => segment.mask);
//   // Apply the mask
//   for (let mask of masks) {
//     for (let y = 0; y < mask.height; y++) {
//       for (let x = 0; x < mask.width; x++) {
//         if (mask.data[y * mask.width + x]) {
//           image.setPixelColor(Jimp.rgbaToInt(0, 0, 0, 0), x, y);
//         }
//       }
//     }
//   }

//   // Resize image if it's larger than 4 MB
//   const maxSize = 4 * 1024 * 1024;
//   if (image.bitmap.data.length > maxSize) {
//     const scaleFactor = Math.sqrt(maxSize / image.bitmap.data.length);
//     const width = Math.floor(image.bitmap.width * scaleFactor);
//     const height = Math.floor(image.bitmap.height * scaleFactor);
//     image = image.resize(width, height);
//   }
//   // Resize image to fit within 1024x1024
//   const scaleFactor = 1024 / Math.max(image.bitmap.width, image.bitmap.height);
//   let width = Math.floor(image.bitmap.width * scaleFactor);
//   let height = Math.floor(image.bitmap.height * scaleFactor);
//   image = image.resize(width, height);

//   // Create a new 1024x1024 white image
//   let transparentImage = new Jimp(1024, 1024, Jimp.rgbaToInt(0, 0, 0, 0));
  
//   // Calculate the position to center the image
//   let x = (1024 - width) / 2;
//   let y = (1024 - height) / 2;
//   // Composite the original image onto the white image
//   transparentImage = transparentImage.composite(image, x, y);
//   // Now use transparentImage instead of image
//   image = transparentImage;

//   const processedImageBuffer = await image.getBufferAsync(Jimp.MIME_PNG);
//   const maskKey = `${fileName}-mask-${Date.now()}`;
//   const maskParams = {
//     Bucket: process.env.AWS_BUCKET_NAME,
//     Key: maskKey,
//     Body: processedImageBuffer,
//     ContentType: "image/png",
//   };
//   const maskCommand = new PutObjectCommand(maskParams);
//   await s3Client.send(maskCommand);
//   const s3URLMaskImg = `https://${process.env.AWS_BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${maskKey}`;
//   return s3URLMaskImg;
// }

export async function POST(request) {
  try {
    const formData = await request.formData();
    const file = formData.get("file");
    if (!file) {
      return NextResponse.error(new Error("No file uploaded"));
    }
    const buffer = Buffer.from(await file.arrayBuffer());
    const s3URL = await uploadFileToS3(buffer, file.name);
    const s3URLWhiteBG = await whiteBackgroundImage(buffer, file.name);
    const s3URLMaskImg = await maskImage(buffer, file.name);
    // const s3URLMaskImgWhiteBG = await maskImageWhiteBg(buffer, file.name);
    const newEntry = await prisma.test.create({
      data: {
        url: s3URL,
        urlWhiteBg: s3URLWhiteBG,
        urlMask: s3URLMaskImg,
        // urlMaskWhiteBg: s3URLMaskImgWhiteBG,
      },
    });
    return NextResponse.json({
      s3URLWhiteBG,
      s3URL,
      newEntry,
      success: true,
    });
  } catch (error) {
    return NextResponse.json({
      error: error.message,
    });
  }
}
