//save clerk id to prisma

import { PrismaClient } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { currentUser } from "@clerk/nextjs";

//Lets trigger this earlier? like on acc creation

const prisma = new PrismaClient();

export async function POST() {
  const user = await currentUser();
  const clerkId = user.id;

  //check if userID is saved to prisma

  const userExists = await prisma.test.findFirst({
    where: {
      userId: clerkId,
    },
  });

  if (userExists) {
    // if yes, do nothing
    // return NextResponse.redirect("/dashboard");
    return NextResponse.json({
      message: "User ID already exists",
    });
  }
  if (!userExists) {
    // if not save it
    await prisma.test.create({
      data: {
        //add first name
        //add last name
        userId: clerkId,
        url: "",
        urlMask: "",
        urlWhiteBg: "",
      },
    });
  }

  return NextResponse.json({
    message: "User ID saved",
  });

  // if not save it
  // if yes, do nothing
}
