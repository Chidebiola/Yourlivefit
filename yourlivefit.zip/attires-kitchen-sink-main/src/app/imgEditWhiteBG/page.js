"use client";

import { useState, useEffect } from "react";
// import { StatusBar } from 'expo-status-bar';
// import { StyleSheet, Text, View, Button } from 'react-native';
// const Separator = () => <View style={styles.separator} />;

export default function App() {


  const [originalImage, setOriginalImage] = useState("");


  //load img from s3
  useEffect(() => {
    const img = new Image();

    //make an API call to get the image
    img.crossOrigin = "Anonymous"; // This enables CORS
    img.src = "https://outfit-visualizer.s3.us-west-1.amazonaws.com//tmp/European-Fashion-Influences-on-Kelseyybarnes.png-1704965038321";

    img.onload = () => {
      if (img.width !== img.height) {
        const minVal = Math.min(img.width, img.height);
        setup(img, 0, 0, minVal, minVal);
      } else {
        setup(img, 0, 0, img.width, img.height);
      }
    };
  }, []); 


  // main edit 
  const setup = (img, x, y, width, height) => {
    const node = document.getElementById("PictureLayer");
    if (node && node.parentNode) {
      node.parentNode.removeChild(node);
    }

    let can = document.createElement("canvas");
    can.id = "PictureLayer";
    can.width = window.innerWidth * 0.45;
    can.height = window.innerWidth * 0.45;
    can.style = "margin:auto;";
    const outerCanvas = document.getElementById("outer-canvas");
    outerCanvas.appendChild(can);

    let ctx = can.getContext("2d");
    ctx.drawImage(img, x, y, width, height, 0, 0, can.width, can.height);
    ctx.lineCap = "round";
    //have this editable with a slider
    ctx.lineWidth = 25;
    ctx.globalCompositeOperation = "destination-out";
    let isDrawing = false;

    const startDrawing = (event) => {
      isDrawing = true;
      const pos = getPos(event);
      console.log("start erasing", pos);
      points.setStart(pos.x, pos.y);
    };
    const stopDrawing = () => {
      console.log("stop erasing");
      isDrawing = false;
    };
    const draw = (event) => {
      if (!isDrawing) return;
      const pos = getPos(event);
      points.newPoint(pos.x, pos.y);
    };

    let points = (function () {
      let queue = [],
        qi = 0;

      function clear() {
        queue = [];
        qi = 0;
      }

      function setStart(x, y) {
        clear();
        newPoint(x, y);
      }

      function newPoint(x, y) {
        queue.push([x, y]);
      }

      function tick() {
        let k = 20; // adjust to limit points drawn per cycle
        if (queue.length - qi > 1) {
          ctx.beginPath();
          if (qi === 0) ctx.moveTo(queue[0][0], queue[0][1]);
          else ctx.moveTo(queue[qi - 1][0], queue[qi - 1][1]);

          for (++qi; --k >= 0 && qi < queue.length; ++qi) {
            ctx.lineTo(queue[qi][0], queue[qi][1]);
          }
          ctx.stroke();
        }
      }

      setInterval(tick, 50); // adjust cycle time

      return {
        setStart: setStart,
        newPoint: newPoint,
      };
    })();

    window.addEventListener("touchstart", startDrawing);
    window.addEventListener("mouseup", stopDrawing);
    can.addEventListener("touchend", stopDrawing);
    can.addEventListener("mousedown", startDrawing);
    can.addEventListener("mousemove", draw);
    can.addEventListener("touchmove", draw);

    function getPos(e) {
      let rect = can.getBoundingClientRect();
      if (e.touches) {
        return {
          x: e.touches[0].clientX - rect.left,
          y: e.touches[0].clientY - rect.top,
        };
      }
      return { x: e.clientX - rect.left, y: e.clientY - rect.top };
    }
    setOriginalImage(can.toDataURL());
  };


  //instead of downloading, send to server to send to s3
  const downloadMask = () => {
    console.log("download mask");
    const node = document.getElementById("PictureLayer");
    if (!node) return;
    let link = document.createElement("a");
    link.download = "mask.png";
    link.href = node.toDataURL();
    link.click();
  };



  
  //turn to tsx w/ tailwind
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <h2 style={{ textAlign: "center", margin: "8px" }}>
        DALL-E 2 Image Mask Editor
      </h2>
      <p style={{ textAlign: "center", margin: "8px" }}>
        {/* 1. <input type="file" accept="image/*" onChange={fileSelected} /> */}
      </p>
      <div>
        <p style={{ textAlign: "center", margin: "8px" }}>
          2. Use mouse to erase parts of the photo that should be edited by AI
        </p>
        <div
          style={{ width: "45vw", height: "45vw", border: "1px solid black" }}
          id="outer-canvas"
        />
      </div>
      <div>
        <p style={{ textAlign: "center", margin: "8px" }}>3. Download Images</p>
        <div style={{ margin: "8px" }}>
          {/* <button style={{ margin: "10px" }} onClick={downloadOriginal}> */}
            {/* Download Original */}
          {/* </button> */}
        </div>
        <div style={{ margin: "8px" }}>
          <button style={{ margin: "10px" }} onClick={downloadMask}>
            Download Mask
          </button>
        </div>
      </div>
    </div>
  );
}
