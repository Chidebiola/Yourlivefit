// @ts-nocheck
"use client";

import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import { Switch } from "@/components/ui/switch";
import { useState, useEffect } from "react";
import Header from "@/components/header";

export default function Home() {
  //to send to Dalle
  const [bgImg, setBgImg] = useState("");
  //to display most recent image with white background
  const [whiteBgImg, setWhiteBgImg] = useState("");
  const [mostRecentImage, setMostRecentImage] = useState("");
  const [stabilityData, setStabilityData] = useState({ image: "" });

  const getMostRecentImage = async () => {
    // console.log('called')
    const response = await fetch("/api/getRecentImage", { cache: "no-store" });
    const data = await response.json();
    // console.log("MOST RECENT IMG", data);
    setBgImg(data.urlMask);
    setWhiteBgImg(data.urlWhiteBg);
    setMostRecentImage(data.url);
  };

  useEffect(() => {
    getMostRecentImage();
  }, []);

  const [dalleResultWithBG, setDalleResultWithBG] = useState("");
  const [dalleResult, setDalleResult] = useState("");
  const [clientContent, setClientContent] = useState("describe outfit");
  const [isLoading, setIsLoading] = useState(false);

  //call Dalle and get result URL for image
  const callStability = async () => {
    setIsLoading(true);
    try {
      console.log(bgImg, "BGIMG");
      // const encodedUrl = encodeURIComponent(bgImg);
      const stabilityResponse = await fetch("/api/stability", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          input: clientContent,
          url: bgImg,
        }), // Pass the URL from the previous response
      });
      console.log("Header");
      const stabilityData = await stabilityResponse.json();
      console.log(stabilityData, "Stability Data");
      setStabilityData(stabilityData); // Update the state with the new data
    } catch (error) {
      setDalleResult({ error: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  const [imgBg, setImgBg] = useState(true);

  const toggleImgBg = () => {
    setImgBg(!imgBg);
  };

  const [seeOriginal, setSeeOriginal] = useState(true);
  const toggleSeeOriginal = () => {
    setSeeOriginal(!seeOriginal);
  };

  return (
    <div className="backgroundStyle h-screen w-screen flex flex-col">
      <Header getMostRecentImage={getMostRecentImage} />
      <main className="flex flex-col flex-grow items-center space-y-10 mt-10">
        <div className="w-4/5 md:w-1/2 flex flex-col space-y-2 ">
          <div className="flex flex-row space-x-2 text-sm items-center pl-1">
            <p>Background</p>
            <Switch
              checked={imgBg}
              onCheckedChange={toggleImgBg}
              aria-label="Toggle Background"
            />

            <p>Original Image</p>

            <Switch
              checked={seeOriginal}
              onCheckedChange={toggleSeeOriginal}
              aria-label="Toggle Original Image"
            />
          </div>
          <div className="flex flex-row space-x-2">
            {/* <Input
              value={clientContent}
              onChange={(e) => setClientContent(e.target.value)}
              type="email"
              placeholder="Tell the AI what to design"
            /> */}
            <Button
              onClick={() => {
                callStability();
                setSeeOriginal(false);
              }}
              disabled={isLoading}
              id="Activate Visualizer AI"
              type="submit"
            >
              {isLoading ? "Generating..." : "Random Outfit"}
            </Button>
          </div>
        </div>
        <div className="h-[512px]  bg-white">
          <img src={stabilityData.image} alt="Generated Image" />

          {/* {dalleResult.image && imgBg === false && seeOriginal === false && (
            <Image
              src={dalleResult.image}
              alt="Image"
              width={512}
              height={512}
            />
          )}

          {dalleResultWithBG.image &&
            imgBg === true &&
            seeOriginal === false && (
              <Image
                src={dalleResultWithBG.image.data[0].url}
                alt="Image"
                width={512}
                height={512}
              />
            )}
          {/* add input for image editing */}
          {/* {seeOriginal === true && imgBg === false && (
            <Image width={512} height={512} alt="" src={whiteBgImg} />
          )}
          {seeOriginal === true && imgBg === true && (
            <Image width={512} height={512} alt="" src={mostRecentImage} />
          )} */} 
        </div>
      </main>
    </div>
  );
}
