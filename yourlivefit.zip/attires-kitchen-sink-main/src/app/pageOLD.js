"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { data } from "autoprefixer";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";

export default function Home() {
  //S3 UPLOAD
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  //to send to Dalle
  const [bgImg, setBgImg] = useState("");
  //to display most recent image with white background
  const [whiteBgImg, setWhiteBgImg] = useState("");
  const [mostRecentImage, setMostRecentImage] = useState("");



  
  const getMostRecentImage = async () => {
    const response = await fetch("/api/getRecentImage", { cache: "no-store" });
    const data = await response.json();
    console.log("MOST RECENT IMG", data);
    setBgImg(data.urlMask);
    setWhiteBgImg(data.urlWhiteBg);
    setMostRecentImage(data.url);
  };

  useEffect(() => {
    getMostRecentImage();
  }, []);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!file) return;

    setUploading(true);

    const formData = new FormData();

    formData.append("file", file);

    try {
      const response = await fetch("/api/baseImage", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();

      console.log(data.status);

      setUploading(false);
      getMostRecentImage();
    } catch (error) {
      console.error(error);
      setUploading(false);
    }
  };

  const [dalleResultWithBG, setDalleResultWithBG] = useState("");

  const [dalleResult, setDalleResult] = useState("");
  const [clientContent, setClientContent] = useState("describe outfit");
  const [isLoading, setIsLoading] = useState(false);

  //call Dalle and get result URL for image
  const callDalle = async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/dalleImgEdit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          input: clientContent,
          imgURL: bgImg,
        }),
      });
      const data = await response.json();
      setDalleResultWithBG(data);
      // setDalleResult(data);
      console.log("DALLE RESULT", data);
      if (data.image && data.image.data[0] && data.image.data[0].url) {
        const url = data.image.data[0].url;
        console.log(url, "WHAT IS THIS URL????");

        // Now that we have the URL, we can make another POST request
        const response2 = await fetch("/api/dalleImgEditWhiteBG", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ url }), // Pass the URL in the body
        });
        const data2 = await response2.json();
        setDalleResult(data2);
        console.log("DALLE RESULT 2", dalleResult);
        // Do something with data2...
      }
    } catch (error) {
      setDalleResult({ error: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  const [imgBg, setImgBg] = useState(true);
  const toggleImgBg = () => {
    setImgBg(!imgBg);
  };

  const [seeOriginal, setSeeOriginal] = useState(true);
  const toggleSeeOriginal = () => {
    setSeeOriginal(!seeOriginal);
  };

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-12">
      <h4 className="text-sm font-bold text-center">
        Describe the outfit you want to visualize.
      </h4>
      <input
        className="border-2 border-gray-300 p-2 w-full rounded-md"
        type="text"
        value={clientContent}
        onChange={(e) => setClientContent(e.target.value)}
      />
      <div className="flex flex-row space-x-2">
        <button
          className={`font-bold py-2 px-4 rounded ${
            isLoading ? "bg-gray-500" : "bg-blue-500 hover:bg-blue-700"
          } text-white`}
          onClick={() => {
            callDalle();
            setSeeOriginal(false);
          }}
          disabled={isLoading}
        >
          {isLoading ? "Loading..." : "Fetch Result"}
        </button>
      </div>

      <button className="border-2 border-gray-500" onClick={toggleImgBg}>
        Toggle Image Background
      </button>
      <button className="border-2 border-gray-500" onClick={toggleSeeOriginal}>
        Toggle see original
      </button>

      {/* <div style={{ minHeight: "512px" }}> */}
      {dalleResult.image && imgBg === false && seeOriginal === false && (
        <Image src={dalleResult.image} alt="Image" width={512} height={512} />
      )}

      {dalleResultWithBG.image && imgBg === true && seeOriginal === false && (
        <Image
          src={dalleResultWithBG.image.data[0].url}
          alt="Image"
          width={512}
          height={512}
        />
      )}

      {/* add input for image editing */}

      {seeOriginal === true && imgBg === false && (
        <Image width={512} height={512} alt="" src={whiteBgImg} />
      )}

      {seeOriginal === true && imgBg === true && (
        <Image width={512} height={512} alt="" src={mostRecentImage} />
      )}
      {/* </div> */}

      {/* <input
        type="text"
        className="w-full max-w-xs p-2 border border-gray-300 rounded mb-4"
        placeholder="Enter text here"
        onInput={(e) => {
          classify(e.target.value);
        }}
      />

      {ready !== null && (
        <pre className="bg-gray-100 p-2 rounded">
          {!ready || !result ? "Loading..." : JSON.stringify(result, null, 2)}
        </pre>
      )} */}

      {/* make this work */}
      <Slider defaultValue={[33]} max={100} step={1} />

      <h1>Upload Files to S3 Bucket</h1>
      {/* <Button variant="outline">Button</Button> */}

      <form onSubmit={handleSubmit}>
        <input type="file" onChange={handleFileChange} />
        <button
          className="border-2 border-gray-500"
          type="submit"
          disabled={!file || uploading}
        >
          {uploading ? "Uploading..." : "Upload"}
        </button>
      </form>

      <button onClick={getMostRecentImage}>Get Most Recent Image</button>
    </main>
  );
}
