import { NextResponse } from "next/server";

import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
// const testData = "meow";

export async function POST() {
  try {

    const newEntry = await prisma.test.create({
      data: {
        url: "meow",
      },
    });

    // const newEntry = await prisma.inquiry.create({
    //   data: {
    //     name: "body.firstName",
    //     email: "body.email",
    //     subject: "body.subject",
    //     message: "body.message"
    //   }
    // })

    return NextResponse.json({ newEntry, success: true });
  } catch (error) {
    console.error("Request error", error);
    return NextResponse.error(
      { error: "Error creating question", success: false },
      500
    );
  }
}





// export async function GET() {
//   console.log("HERE");
//   return NextResponse.json({ message: "Hello world!" });
// }
