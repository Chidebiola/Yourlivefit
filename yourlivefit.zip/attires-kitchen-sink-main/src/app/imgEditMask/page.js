"use client";

import { useState, useEffect } from "react";
import { Slider } from "@/components/ui/slider"


export default function App() {
  // load img from s3
  useEffect(() => {
    const img = new Image();
    img.crossOrigin = "Anonymous";
    img.src =
      "https://outfit-visualizer.s3.us-west-1.amazonaws.com/demoImg-1.png-whiteBackground-1704711834282";
    const originalImg = new Image();
    originalImg.crossOrigin = "Anonymous";
    originalImg.src =
      "https://outfit-visualizer.s3.us-west-1.amazonaws.com/demoImg-1.png-1704711830038";

    let imgLoaded = false;
    let originalImgLoaded = false;

    img.onload = () => {
      imgLoaded = true;
      if (originalImgLoaded) {
        setup(img, originalImg, 0, 0, img.width, img.height);
      }
    };

    originalImg.onload = () => {
      originalImgLoaded = true;
      if (imgLoaded) {
        setup(img, originalImg, 0, 0, img.width, img.height);
      }
    };
  }, []);

  // manage what is being drawn
  let state = {
    isDrawing: false,
    isReturning: false,
  };
  let returnState = {
    returnOg: false,
  };

  // Function to create a canvas
  const createCanvas = (id, width, height, style) => {
    let can = document.createElement("canvas");
    can.id = id;
    can.width = width;
    can.height = height;
    can.style = style;
    return can;
  };

  // Function to draw image on canvas
  const drawImageOnCanvas = (ctx, img, x, y, width, height, can) => {
    ctx.drawImage(img, x, y, width, height, 0, 0, can.width, can.height);
  };

  // Function to return original image
  // TODO: make this image from a different source
  const returnOriginal = (event, ctx, originalCtx, getPos) => {
    const pos = getPos(event);
    const currentCompositeOperation = ctx.globalCompositeOperation;
    ctx.globalCompositeOperation = "source-over";
    const radius = ctx.lineWidth / 2;
    const imageData = originalCtx.getImageData(
      pos.x - radius,
      pos.y - radius,
      radius * 2,
      radius * 2
    );
    let tempCanvas = document.createElement("canvas");
    let tempCtx = tempCanvas.getContext("2d");
    tempCanvas.width = radius * 2;
    tempCanvas.height = radius * 2;
    tempCtx.putImageData(imageData, 0, 0);
    tempCtx.globalCompositeOperation = "destination-in";
    tempCtx.beginPath();
    tempCtx.arc(radius, radius, radius, 0, Math.PI * 2);
    tempCtx.fill();
    ctx.drawImage(tempCanvas, pos.x - radius, pos.y - radius);
    ctx.globalCompositeOperation = currentCompositeOperation;
  };

  // Function to start drawing
  const startDrawing = (event, isDrawing, points, getPos) => {
    state.isDrawing = true;
    const pos = getPos(event);
    points.setStart(pos.x, pos.y);
  };

  // Function to stop drawing
  const stopDrawing = () => {
    state.isDrawing = false;
  };

  // Function to draw
  const draw = (event, isDrawing, points, getPos) => {
    if (!state.isDrawing) return;
    const pos = getPos(event);
    points.newPoint(pos.x, pos.y);
  };

  const startReturning = (event, ctx, originalCtx, state, getPos, can) => {
    state.isReturning = true;
    returnOriginal(event, ctx, originalCtx, () => getPos(event, can));
  };

  // Function to stop returning
  const stopReturning = (state) => {
    state.isReturning = false;
  };

  // Function to return
  const returnOg = (event, ctx, originalCtx, state, getPos, can) => {
    if (!state.isReturning) return;
    returnOriginal(event, ctx, originalCtx, () => getPos(event, can));
  };

  // Function to manage points
  const managePoints = (ctx) => {
    let queue = [],
      qi = 0;

    function clear() {
      queue = [];
      qi = 0;
    }

    function setStart(x, y) {
      clear();
      newPoint(x, y);
    }
    function newPoint(x, y) {
      queue.push([x, y]);
    }
    function tick() {
      let k = 20;
      if (queue.length - qi > 1) {
        ctx.beginPath();
        if (qi === 0) ctx.moveTo(queue[0][0], queue[0][1]);
        else ctx.moveTo(queue[qi - 1][0], queue[qi - 1][1]);

        for (++qi; --k >= 0 && qi < queue.length; ++qi) {
          ctx.lineTo(queue[qi][0], queue[qi][1]);
        }
        ctx.stroke();
      }
    }
    setInterval(tick, 50);
    return {
      setStart: setStart,
      newPoint: newPoint,
    };
  };

  // Function to get position
  const getPos = (e, can) => {
    let rect = can.getBoundingClientRect();
    if (e.touches) {
      return {
        x: e.touches[0].clientX - rect.left,
        y: e.touches[0].clientY - rect.top,
      };
    }
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  // Main setup function
  const setup = (img, originalImg, x, y, width, height) => {
    const node = document.getElementById("PictureLayer");
    if (node && node.parentNode) {
      node.parentNode.removeChild(node);
    }

    let can = createCanvas(
      "PictureLayer",
      window.innerWidth * 0.45,
      window.innerWidth * 0.45,
      "margin:auto;"
    );

    const outerCanvas = document.getElementById("outer-canvas");
    outerCanvas.appendChild(can);
    let ctx = can.getContext("2d");
    // drawImageOnCanvas(ctx, img, x, y, width, height, can);
    drawImageOnCanvas(ctx, img, x, y, width, height, can);

    ctx.lineCap = "round";

    //have this editable with a slider
    ctx.lineWidth = 25;
    ctx.globalCompositeOperation = "destination-out";

    // Create a separate canvas for the original image
    let originalCanvas = createCanvas("originalCanvas", can.width, can.height);
    let originalCtx = originalCanvas.getContext("2d");
    drawImageOnCanvas(originalCtx, originalImg, x, y, width, height, can);

    can.addEventListener("mousedown", (event) => {
      if (returnState.returnOg) {
        startReturning(
          event,
          ctx,
          originalCtx,
          state,
          () => getPos(event, can),
          can
        );
      } else {
        startDrawing(event, state, points, () => getPos(event, can));
      }
    });

    can.addEventListener("mouseup", () => {
      stopReturning(state);
      stopDrawing(state);
    });

    can.addEventListener("mousemove", (event) => {
      if (returnState.returnOg) {
        returnOg(event, ctx, originalCtx, state, () => getPos(event, can), can);
      } else {
        draw(event, state, points, () => getPos(event, can));
      }
    });

    let points = managePoints(ctx);
  };

  const downloadMask = () => {
    console.log("download mask");
    const node = document.getElementById("PictureLayer");
    if (!node) return;
    let link = document.createElement("a");
    link.download = "mask.png";
    link.href = node.toDataURL();
    link.click();
  };

  //turn to tsx w/ tailwind
  return (
    
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
      }}
    >

      <p style={{ textAlign: "center", margin: "8px" }}></p>
      <div>
        {/* <p style={{ textAlign: "center", margin: "8px" }}>
          2. Use mouse to erase parts of the photo that should be edited by AI
        </p> */}
        <div
          style={{ width: "45vw", height: "45vw", border: "1px solid black" }}
          id="outer-canvas"
        />
      </div>
      <div>
        <p style={{ textAlign: "center", margin: "8px" }}>3. Download Images</p>
        <div style={{ margin: "8px" }}></div>
        <div></div>
        <div>
          <button
            onClick={() => {
              returnState.returnOg = !returnState.returnOg;
            }}
          >
            Return Original
          </button>
        </div>
        <div style={{ margin: "8px" }}>
          <button style={{ margin: "10px" }} onClick={downloadMask}>
            Download Mask
          </button>
        </div>
      </div>
    </div>
  );
}



