// @ts-nocheck
"use client";

import {
  Menubar,
  MenubarContent,
  MenubarItem,
  MenubarMenu,
  MenubarSeparator,
  MenubarTrigger,
} from "@/components/ui/menubar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import { useState } from "react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useRouter } from "next/navigation";
import logo from "/public/logo.png";
import { UserButton } from "@clerk/nextjs";
import { CreditCard } from "lucide-react";
// import { MeowTest } from "@/components/test"
// import { user-profile }

export default function Header({ getMostRecentImage }) {
  //S3 UPLOAD

  const router = useRouter();
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) return;

    setUploading(true);

    const formData = new FormData();

    formData.append("file", file);

    try {
      const response = await fetch("/api/baseImage", {
        method: "POST",
        body: formData,
      });

      //   const data = await response.json();

      setUploading(false);
      getMostRecentImage();
    } catch (error) {
      console.error(error);
      setUploading(false);
    }
  };

  return (
    <>
      <header className="w-screen h-14 px-2 py-2 md:px-10 space-x-2 flex flex-row items-center justify-between">
        {/* KEEP LOGO OR DELTE AND JUST KEEP NAME??? */}
        <div className="flex flex-row items-center space-x-2">
          <div className="border-2 border-black">
            <Image height={30} width={30} src={logo} />
          </div>

          <span
            className="text-xl hover:cursor-pointer"
            onClick={() => router.push("/visualize")}
          >
            Attires.ai
          </span>
        </div>
        <div className="flex flex-row items-center space-x-2">
          <Menubar>
            <MenubarMenu>
              <MenubarTrigger>Image</MenubarTrigger>

              <MenubarContent className="mr-20 md:mr-32 space-y-1">
                <MenubarItem onClick={() => router.push("/visualize")}>
                  Visualize
                </MenubarItem>
                <MenubarItem onClick={() => router.push("/edit")}>
                  Edit
                </MenubarItem>

                <Popover>
                  <PopoverTrigger
                    className="border-none items-center w-full"
                    asChild
                  >
                    <Button className="px-2 font-normal h-8" variant="outline">
                      {/* Upload New Image */}
                      <span className="text-left block w-full">
                        Upload New Image
                      </span>
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-80">
                    <form
                      className="flex flex-col space-y-1 items-center"
                      onSubmit={handleSubmit}
                    >
                      <Input
                        id="picture"
                        type="file"
                        onChange={handleFileChange}
                      />

                      <Button
                        className="w-36 border-2 border-gray-500"
                        type="submit"
                        disabled={!file || uploading}
                      >
                        {uploading ? "Uploading..." : "Upload"}
                      </Button>
                    </form>
                  </PopoverContent>
                </Popover>
              </MenubarContent>
            </MenubarMenu>
            <MenubarMenu>
              {/* <MenubarTrigger>Account</MenubarTrigger>
            <MenubarContent className="mr-2 md:mr-10">
              <MenubarItem>Settings</MenubarItem>
              <MenubarSeparator />
              <MenubarItem>Logout</MenubarItem>
            </MenubarContent> */}
            </MenubarMenu>
          </Menubar>
          {/* //signin signout */}

          <UserButton afterSignOutUrl="/">
            <UserButton.UserProfileLink
              label="Payments"
              labelIcon={<CreditCard />}
              url="/payments"
            />
          </UserButton>
        </div>
      </header>
    </>
  );
}
