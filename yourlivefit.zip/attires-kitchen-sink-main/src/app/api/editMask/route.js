import { NextResponse } from "next/server";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { PrismaClient } from "@prisma/client";
// import PipelineSingleton from "./pipeline.js";
import Jimp from "jimp";

export const maxDuration = 100;

const prisma = new PrismaClient();
const s3Client = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

// replace all the useless resize and stuff in here - not needed

async function uploadFileToS3(file, fileName) {
  let image = await Jimp.read(file);

    // Resize image if it's larger than 4 MB
    const maxSize = 4 * 1024 * 1024; // 4 MB in bytes
    if (image.bitmap.data.length > maxSize) {
      const scaleFactor = Math.sqrt(maxSize / image.bitmap.data.length);
      const width = Math.floor(image.bitmap.width * scaleFactor);
      const height = Math.floor(image.bitmap.height * scaleFactor);
      image = image.resize(width, height);
    }
  
    // Resize image to fit within 1024x1024
    const scaleFactor = 1024 / Math.max(image.bitmap.width, image.bitmap.height);
    let width = Math.floor(image.bitmap.width * scaleFactor);
    let height = Math.floor(image.bitmap.height * scaleFactor);
    image = image.resize(width, height);
    // Create a new 1024x1024 white image
    let transparentImage = new Jimp(1024, 1024, Jimp.rgbaToInt(0, 0, 0, 0));
    // Calculate the position to center the image
    let x = (1024 - width) / 2;
    let y = (1024 - height) / 2;
    // Composite the original image onto the white image
    transparentImage = transparentImage.composite(image, x, y);
    // Now use transparentImage instead of image
    image = transparentImage;
  
    const processedImageBuffer = await image.getBufferAsync(Jimp.MIME_PNG);
  
  const key = `${fileName}-${Date.now()}`;

  const params = {
    Bucket: process.env.AWS_BUCKET_NAME,
    Key: key,
    Body: processedImageBuffer,
    ContentType: "image/png",
  };

  const command = new PutObjectCommand(params);
  await s3Client.send(command);
  const s3URL = `https://${process.env.AWS_BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`;
  return s3URL;
}

export async function POST(request) {
  try {
    const formData = await request.formData();
    const file = formData.get("file");
    if (!file) {
      return NextResponse.error(new Error("No file uploaded"));
    }
    const buffer = Buffer.from(await file.arrayBuffer());
    const s3URL = await uploadFileToS3(buffer, file.name);
    const latestEntry = await prisma.test.findFirst({
      orderBy: {
        id: 'desc', // Replace 'id' with your timestamp field if you have one
      },
    });

    if (!latestEntry) {
      return NextResponse.error(new Error("No entries found"));
    }

    // Update the latest entry
    const updatedEntry = await prisma.test.update({
      where: {
        id: latestEntry.id,
      },
      data: {
        urlMask: s3URL,
      },
    });


    return NextResponse.json({
      s3URL,
      updatedEntry,
      success: true,
    });
  } catch (error) {
    return NextResponse.json({
      error: error.message,
    });
  }
}
