import OpenAI from "openai";
import fetch from "node-fetch";
import FormData from "form-data";



//increase timeout to 25s instead of 10s
export const runtime = "edge";
export const maxDuration = 100;

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function POST(request) {
  
  const { input, imgURL } = await request.json();
// const input = "This is a test prompt";

// let inputLoop = input + ". ";
//   for (let i = 0; i < 10; i++) {
//     // console.log(i);
//     inputLoop += input + ". ";
//   }

  // console.log(inputLoop, "inputLoop")

  //hacky solution to get image from url
      const imageUrl = imgURL;
      const response = await fetch(imageUrl);
      const blob = await response.blob();
      const formData = new FormData();
      formData.append("image", blob, "image.png");

      
      const result = await openai.images.edit({
        image: formData.get("image"),
        prompt: input,
      });

      
      // console.log(result, "result")

  return new Response(JSON.stringify({ image: result }), { status: 200 });
}