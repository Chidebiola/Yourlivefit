"use client";

//THIS WILL CREATRE A  /user-profile page NO NEED FOR IT AT THE MOMENT 

import { UserProfile } from "@clerk/nextjs";
// import { MyCustomPageContent } from "../components";
// import { CustomIcon, Icon } from "../icons";
import { Pencil } from "lucide-react";

const UserProfilePage = () => (
  <UserProfile path="/user-profile" routing="path">
    <UserProfile.Link label="Payment" labelIcon={<Pencil />} url="/" />
  </UserProfile>
);

export default UserProfilePage;
