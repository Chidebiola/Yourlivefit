"use client";
import getStripe from "@/lib/get-stripe";
import { Button } from "./ui/button";

//Get user ID from clerk

export default function StripeComponent() {
  //keep hardcoded or pass dynamically?
  const priceId = "price_1OaWGYJNUzvngvZQFX9kQHWk";

  //need to pass user ID?
  const addClerkId = async () => {
    const res = await fetch("/api/saveClerkId", {
      method: "POST",
      // body: JSON.stringify(), // Send priceId as an object
      headers: {
        "Content-Type": "application/json",
      },
    });
  };

  //check to make sure user does not have active billing & on sucess make sure to update billing to active (either here on in the API..)
  const handleCreateCheckoutSession = async (priceId: string) => {
    const res = await fetch("/api/checkout-session", {
      method: "POST",
      body: JSON.stringify({ priceId }), // Send priceId as an object
      headers: {
        "Content-Type": "application/json",
      },
    });
    const checkoutSession = await res.json().then((value) => {
      return value.session;
    });
    const stripe = await getStripe();
    const { error } = await stripe!.redirectToCheckout({
      sessionId: checkoutSession.id,
    });
  };

  return (
    <div>
      {/* if user has not paid allow them to start checkout session */}
      <Button
        onClick={() => {
          addClerkId()
          // handleCreateCheckoutSession(priceId);
        }}
      >
        trigger Stripe checkout session
      </Button>

      {/* if user has paid 
             allow for cancel 
             slow billing items (1 row per payment) */}
    </div>
  );
}
